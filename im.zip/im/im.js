let token = "";
(function() {
  $.ajax({
    type: "POST",
    url:
      "https://dev170.weibanker.cn/hongjh/www/yumianhu/api?url=getRongCloudToKen",
    data: { access_token: "6o3VPYZDO5hTluCTana3zsCbHb9hhKye" },
    dataType: "json",
    success: function(data) {
      console.log(data.data.token);
      token = data.token;
    }
  });
})();

RongIMLib.RongIMClient.init("3argexb63quqe");
RongIMClient.setConnectionStatusListener({
  onChanged: function(status) {
    console.log(status)
    switch (status) {
      case RongIMLib.ConnectionStatus.CONNECTED:
        console.log("链接成功");
        var conversationType = RongIMLib.ConversationType.PRIVATE;
        var targetId = "userid1";
        RongIMLib.RongIMClient.getInstance().getUnreadCount(
          conversationType,
          targetId,
          {
            onSuccess: function(count) {
              // count => 指定会话的总未读数。
            },
            onError: function() {
              // error => 获取指定会话未读数错误码。
            }
          }
        );
        RongIMClient.getInstance().getTotalUnreadCount({
          onSuccess: function(count) {
            // count => 所有会话总未读数。
            console.log(count);
          },
          onError: function(error) {
            // error => 获取总未读数错误码。
          }
        });
        break;
      case RongIMLib.ConnectionStatus.CONNECTING:
        console.log("正在链接");
        break;
      case RongIMLib.ConnectionStatus.DISCONNECTED:
        console.log("断开连接");
        break;
      case RongIMLib.ConnectionStatus.KICKED_OFFLINE_BY_OTHER_CLIENT:
        console.log("其他设备登录");
        break;
      case RongIMLib.ConnectionStatus.DOMAIN_INCORRECT:
        console.log("域名不正确");
        break;
      case RongIMLib.ConnectionStatus.NETWORK_UNAVAILABLE:
        console.log("网络不可用");
        break;
    }
  }
});
// 消息监听器
RongIMClient.setOnReceiveMessageListener({
  // 接收到的消息
  onReceived: function(message) {
    console.log("接受到的信息message：");
    console.log(message);
  }
});
RongIMClient.connect(
  token,
  {
    onSuccess: function(userId) {
      console.log("Connect successfully." + userId);
      userid_send = userId;
    },
    onTokenIncorrect: function() {
      console.log("token无效");
    },
    onError: function(errorCode) {
      var info = "";
      switch (errorCode) {
        case RongIMLib.ErrorCode.TIMEOUT:
          info = "超时";
          break;
        case RongIMLib.ConnectionState.UNACCEPTABLE_PAROTOCOL_VERSION:
          info = "不可接受的协议版本";
          break;
        case RongIMLib.ConnectionState.IDENTIFIER_REJECTED:
          info = "appkey不正确";
          break;
        case RongIMLib.ConnectionState.SERVER_UNAVAILABLE:
          info = "服务器不可用";
          break;
      }
      console.log(errorCode);
    }
  }
);

$('#im_button').on('click', function () {
    // 获取消息内容和uid
    var str=$('#im_input').val();
    if (str=='') {
        alert('请输入聊天内容');
        return false;
    }
    // var messageStr = '<div class="me-dialogue-item clearfix"><div class="chat-head-mask right"><div class="chat-head"><img src="[{$member['headimgurl']}]"></div><div class="t-center mt-5">'+frontOneHour('hh:mm:ss')+'</div></div><div class="me-bubble-mask right"><div class="me-bubble chat-bubble"><div class="bubble-triangle-right"></div><div class="bubble-txt">'+str+'</div></div></div></div>'
    // $('.chat-box-con').append(messageStr);
    // $('.'+uid+'_content').append(messageStr);

    // 发送消息
    rongSendMessage('userid100020',str);
    // 清空消息框中的内容
    $('#im_input').val('');
})
/**
 * 发送消息
 * @param  {integer} uid  用户id
 * @param  {string}  word 发送的消息
 */
function rongSendMessage(uid, word) {
  // 定义消息类型,文字消息使用 RongIMLib.TextMessage
  var msg = new RongIMLib.TextMessage.obtain(word);
  var conversationtype = RongIMLib.ConversationType.PRIVATE; // 私聊
  var targetId = uid; // 目标 Id
  RongIMClient.getInstance().sendMessage(conversationtype, targetId, msg, {
    // 发送消息成功
    onSuccess: function(message) {
      //message 为发送的消息对象并且包含服务器返回的消息唯一Id和发送消息时间戳
      console.log("发送信息返回的message:");
      console.log(message);
    },
    onError: function(errorCode, message) {
      var info = "";
      switch (errorCode) {
        case RongIMLib.ErrorCode.TIMEOUT:
          info = "超时";
          break;
        case RongIMLib.ErrorCode.UNKNOWN_ERROR:
          info = "未知错误";
          break;
        case RongIMLib.ErrorCode.REJECTED_BY_BLACKLIST:
          info = "在黑名单中，无法向对方发送消息";
          break;
        case RongIMLib.ErrorCode.NOT_IN_DISCUSSION:
          info = "不在讨论组中";
          break;
        case RongIMLib.ErrorCode.NOT_IN_GROUP:
          info = "不在群组中";
          break;
        case RongIMLib.ErrorCode.NOT_IN_CHATROOM:
          info = "不在聊天室中";
          break;
        default:
          info = x;
          break;
      }
      console.log("发送失败:" + info);
    }
  });
}
